import pgzrun

# 设置屏幕大小
WIDTH = 620
HEIGHT = 900
# 创建女孩角色并设置角色位置
girl = Actor("co")
girl.pos = 300, 550
# 创建发型列表、发型角色，设置角色位置
hair_style = ['hair_1', 'hair_2', 'hair_3', 'hair_4']
hair = Actor("hair_1")
hair.pos = 317, 469
# 创建服装列表、服装角色，设置角色位置
dress_style = ['dress_1', 'dress_2', 'dress_3', 'dress_4']
dress = Actor("dress_1")
dress.pos = 313, 653
# 创建鞋子列表、鞋子角色，设置角色位置
shoes_style = ['shoes_1', 'shoes_2', 'shoes_3', 'shoes_4']
shoes = Actor("shoes_1")
shoes.pos = 312, 780


def draw():
    # 设置背景
    screen.blit('background', (0, 0))
    # 显示所有角色
    girl.draw()
    hair.draw()
    dress.draw()
    shoes.draw()


# 变换造型函数
def changestyle(obj, styleList):
    style = styleList.index(obj.image)
    if (style < 3):
        obj.image = styleList[style + 1]
    else:
        obj.image = styleList[0]


# 当鼠标按下，让鼠标点击的角色变换造型
def on_mouse_down(pos):
    if dress.collidepoint(pos):
        changestyle(dress, dress_style)
    elif hair.collidepoint(pos):
        changestyle(hair, hair_style)
    elif shoes.collidepoint(pos):
        changestyle(shoes, shoes_style)


pgzrun.go()

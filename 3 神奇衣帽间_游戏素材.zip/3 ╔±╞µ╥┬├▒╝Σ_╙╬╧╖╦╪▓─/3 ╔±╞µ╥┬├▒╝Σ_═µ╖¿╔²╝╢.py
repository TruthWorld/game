import pgzrun
import random


WIDTH = 620
HEIGHT = 900
girl = Actor("co")
girl.pos = 300, 550

hair_style = ['hair_1', 'hair_2', 'hair_3', 'hair_4']
hair = Actor("hair_1")
hair.pos = 317, 469

dress_style = ['dress_1', 'dress_2', 'dress_3', 'dress_4']
dress = Actor("dress_1")
dress.pos = 313, 653

shoes_style = ['shoes_1', 'shoes_2', 'shoes_3', 'shoes_4']
shoes = Actor("shoes_1")
shoes.pos = 312, 780

button1 = Actor("rand")
button1.pos = 120, 120

button2 = Actor("match")
button2.pos = 500, 120


def draw():
    screen.blit('background', (0, 0))
    girl.draw()
    hair.draw()
    dress.draw()
    shoes.draw()
    button1.draw()
    button2.draw()


def changestyle(obj, styleList):
    style = styleList.index(obj.image)
    if (style < 3):
        obj.image = styleList[style + 1]
    else:
        obj.image = styleList[0]


def change_all():
    suit = random.randint(0, 3)
    dress.image = dress_style[suit]
    hair.image = hair_style[suit]
    shoes.image = shoes_style[suit]


def rand_change():
    dress.image = random.choice(dress_style)
    hair.image = random.choice(hair_style)
    shoes.image = random.choice(shoes_style)


def on_mouse_down(pos):
    if dress.collidepoint(pos):
        changestyle(dress, dress_style)
    elif hair.collidepoint(pos):
        changestyle(hair, hair_style)
    elif shoes.collidepoint(pos):
        changestyle(shoes, shoes_style)
    elif button1.collidepoint(pos):
        rand_change()
    elif button2.collidepoint(pos):
        change_all()

pgzrun.go()

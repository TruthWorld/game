import pgzrun
import random
import math

WIDTH = 450
HEIGHT = 650
score = 0
game_state = 'start'
speed = 6
shoot = False
t = 0
attack = False
life = 3

spaceship = Actor('spaceship', (200, 550))
diamond = Actor('diamond', (100, -200))
enermy = Actor('enermy2', (300, -200))
bullet = Actor('bullet', (200, -100))
bullet_red = Actor('bullet_red', (200, -100))
heart = Actor('heart', (300, -5000))


def draw():
    global game_state, shoot, score, life
    if game_state == 'start':
        screen.blit('space', (0, 0))
        screen.draw.text('Spacecraft', (115, 260), fontsize=60)
        screen.draw.text('Press SPACE to start!',
                         (85, 320), fontsize=40)
        if keyboard.space:
            game_state = 'play'
            sounds.bg_music.play(-1)
    elif game_state == 'play':
        screen.blit('space', (0, 0))
        screen.draw.text('score: ' + str(score),
                         (10, 10), fontsize=30)
        screen.draw.text('life: ' + str(life),
                         (370, 10), fontsize=30)
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
    else:
        screen.blit('space', (0, 0))
        spaceship.draw()
        sounds.bg_music.stop()
        screen.draw.text('GAME OVER!', (90, 230),
                         color='red', fontsize=60)
        screen.draw.text('Your score: ' + str(score),
                         (125, 280), fontsize=40)
        screen.draw.text('Press SPACE to restart!',
                         (70, 320), fontsize=40)
        if keyboard.space:
            game_state = 'play'
            place_object(enermy)
            place_object(diamond)
            sounds.bg_music.play(-1)
            score = 0
            life = 3


def place_object(obj):
    obj.x = random.randint(20, WIDTH - 20)
    obj.y = random.randint(-200, -40)


def spaceship_collide(obj):
    global life, game_state
    if spaceship.collidepoint(obj.pos):
        sounds.hit.play()
        place_object(obj)
        life -= 1
        if life == 0:
            game_state = 'game over'


def update():
    global score, game_state, shoot, t, attack, life
    if game_state == 'play':
        enermy.y += speed - 2
        enermy.x = WIDTH / 2 * (1 + math.sin(1.2 * t))
        t += 0.02
        diamond.y += speed
        heart.y += speed

        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        elif keyboard.right:
            spaceship.x += 5

        if spaceship.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

        if keyboard.a:
            shoot = True
            sounds.bullet.play()
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > -20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True

        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False

        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            score += 10

        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            sounds.powerup.play()
            score += 10

        spaceship_collide(enermy)
        spaceship_collide(bullet_red)

        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)

        if spaceship.collidepoint(heart.pos):
            life += 1
            sounds.powerup.play()
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)


pgzrun.go()

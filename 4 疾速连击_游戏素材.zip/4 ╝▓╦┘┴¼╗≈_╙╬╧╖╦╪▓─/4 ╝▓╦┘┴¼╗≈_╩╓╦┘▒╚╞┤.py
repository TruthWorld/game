import pgzrun
from random import randint

WIDTH = 640
HEIGHT = 480
score1 = 0
score2 = 0
button1 = Actor("button1_on")
button1.pos = WIDTH / 4, HEIGHT / 2 + 60
button2 = Actor("button2_on")
button2.pos = WIDTH - WIDTH / 4, HEIGHT / 2 + 60
time_left = 5
game_over = False


def draw():
    screen.fill("lightblue")
    button1.draw()
    button2.draw()
    screen.draw.text("press S: " + str(score1), color="white",
                     center=(WIDTH / 4, 150), fontsize=50)
    screen.draw.text("press L: " + str(score2), color="white",
                     center=(WIDTH - WIDTH / 4, 150), fontsize=50)
    screen.draw.text("Time Left: " + str(time_left),
                     color="white", center=(WIDTH / 2, 40), fontsize=50)
    if game_over:
        screen.fill("lightblue")
        screen.draw.text("player S: " + str(score1),
                         center=(WIDTH / 4, 120), fontsize=50)
        screen.draw.text("player L: " + str(score2),
                         center=(WIDTH - WIDTH / 4, 120), fontsize=50)
        if score1 > score2:
            winner = "The winner is player S!"
        elif score1 < score2:
            winner = "The winner is player L!"
        else:
            winner = "It's a tie!"
        screen.draw.text(winner, center=(WIDTH / 2, HEIGHT / 2), fontsize=60)


def on_key_down(key):
    global score1, score2
    if not game_over:
        if key == keys.S:
            button1.image = "button1_off"
            score1 += 1
        if key == keys.L:
            button2.image = "button2_off"
            score2 += 1


def on_key_up(key):
    if key == keys.S:
        button1.image = "button1_on"
    if key == keys.L:
        button2.image = "button2_on"


def update_time_left():
    global time_left, game_over
    if score1 > 0 or score2 > 0:
        if time_left:
            time_left -= 1
        else:
            game_over = True

clock.schedule_interval(update_time_left, 1.0)

pgzrun.go()

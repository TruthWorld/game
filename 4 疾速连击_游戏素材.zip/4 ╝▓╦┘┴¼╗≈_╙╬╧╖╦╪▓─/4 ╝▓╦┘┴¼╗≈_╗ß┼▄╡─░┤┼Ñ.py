import pgzrun
from random import randint

WIDTH = 640
HEIGHT = 480
score = 0
button = Actor("button1_on")
button.pos = WIDTH / 2, HEIGHT / 2 + 60
time_left = 5
game_over = False


def draw():
    screen.fill("lightblue")
    button.draw()
    screen.draw.text("Score: " + str(score), color="white",
                     center=(WIDTH / 2, 90), fontsize=50)
    screen.draw.text("Time Left: " + str(time_left),
                     color="white", center=(WIDTH / 2, 40), fontsize=50)
    if game_over:
        screen.fill("lightblue")
        screen.draw.text("Final Score: " + str(score),
                         center=(WIDTH / 2, 150), fontsize=50)


def on_mouse_down(pos):
    global score
    if not game_over:
        if button.collidepoint(pos):
            button.image = "button1_off"
            score += 1


def on_mouse_up():
    button.image = "button1_on"
    button.pos = randint(60, WIDTH - 60), randint(60, HEIGHT - 60)


def update_time_left():
    global time_left, game_over
    if score > 0:
        if time_left > 0:
            time_left -= 1
        else:
            game_over = True

clock.schedule_interval(update_time_left, 1.0)

pgzrun.go()

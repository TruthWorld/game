import pgzrun

# 设置屏幕大小
WIDTH = 310
HEIGHT = 450
# 初始分数
score = 0
# 创建按钮角色，设置角色位置
button = Actor("button1_on")
button.center = WIDTH / 2, HEIGHT / 2 + 60
# 剩余时间
time_left = 5
# 游戏状态
game_over = False


def draw():
    # 填充浅蓝色的背景
    screen.fill("lightblue")
    # 显示按钮
    button.draw()
    # 显示分数
    screen.draw.text("Score: " + str(score), color="white",
                     center=(WIDTH / 2, 90), fontsize=50)
    # 显示倒计时
    screen.draw.text("Time Left: " + str(time_left),
                     color="white", center=(WIDTH / 2, 40),
                     fontsize=50)
    # 游戏结束后显示最终得分
    if game_over:
        screen.fill("lightblue")
        screen.draw.text("Final Score: " + str(score),
                         center=(WIDTH / 2, 150), fontsize=50)


# 点击按钮，得分增加
def on_mouse_down(pos):
    global score
    if not game_over:  # 如果游戏没有结束
        if button.collidepoint(pos):
            button.image = "button1_off"
            score += 1


# 松开鼠标按钮复原
def on_mouse_up():
    button.image = "button1_on"


# 倒计时
def update_time_left():
    global time_left, game_over
    if score > 0:
        if time_left > 0:
            time_left -= 1
        else:
            game_over = True

# 每隔 1 秒调用一次倒计时函数
clock.schedule_interval(update_time_left, 1.0)

pgzrun.go()

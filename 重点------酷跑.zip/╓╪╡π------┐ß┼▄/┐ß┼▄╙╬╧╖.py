import pygame
import random
import time
from time import gmtime, strftime
pygame.init()  # 初始化
pygame.display.set_caption("源码变变变")  # 添加标题
keep_going = True

cnt = 0
timer = pygame.time.Clock()
failed = pygame.mixer.Sound("failed.wav")
failed_2 = pygame.mixer.Sound("success.wav")
failed_screen = pygame.image.load("失败.jpg")
font = pygame.font.SysFont("simhei", 28)


class Bird():
    def __init__(self):
        self.img = pygame.image.load("0.png")
        self.x = cacti.x+random.randint(500,1000)
        self.y = 50
        self.speed_x = -20
        self.rect = self.img.get_rect()
        self.rect.center = (self.x+self.img.get_width()/2,
                            self.y+self.img.get_height()/2)

    def get_position(self):
        self.x += self.speed_x
        if self.x < -1 * self.img.get_width():
            self.x = cacti.x+random.randint(500, 1000)
        self.rect.center = (self.x+self.img.get_width()/2,
                            self.y+self.img.get_height()/2)

        return (self.x, self.y)


class Cacti():
    def __init__(self):
        self.img = pygame.image.load("仙人掌.png")
        self.x = 1200 + random.randint(500, 1000)
        self.y = 300 - self.img.get_height()
        self.speed_x = -20
        self.rect = self.img.get_rect()
        self.rect.center = (self.x+self.img.get_width()/2,
                            self.y+self.img.get_height()/2)

    def get_position(self):
        self.x += self.speed_x
        if self.x < -1 * self.img.get_width():
            self.x = 1200 + random.randint(200, 500)
        self.rect.center = (self.x+self.img.get_width()/2,
                            self.y+self.img.get_height()/2)

        return (self.x, self.y)


class Cat():
    def __init__(self):
        self.pose_list = [pygame.image.load("cat_{}.png".format(i))
                          for i in range(29)]  # 加载图片资源
        self.x = 100
        self.y = 100
        self.y_speed = 0
        self.jumpspeed = -15
        self.gravity = 0.8
        self.isjumping = False
        self.rect = self.pose_list[0].get_rect()
        self.rect.center = (self.x+self.pose_list[0].get_width()/2,
                            self.y+self.pose_list[0].get_height()/2)
        self.score = 0
        self.isLanded = False
        self.num = 1

    def jump(self):
        if self.y == 100:
            self.y_speed = self.jumpspeed
            self.isjumping = True
            self.isLanded = False

    def get_position(self):
        if self.isjumping:
            self.y += self.y_speed
            self.y_speed += self.gravity
        if self.y > 100:
            self.y = 100
            self.isjumping = False
            self.y_speed = 0
            self.isLanded = True
        self.rect.center = (self.x+self.pose_list[0].get_width()/2,
                            self.y+self.pose_list[0].get_height()/2)
        return (self.x, self.y)

    def Cruch(self, Obj):
        if self.rect.colliderect(Obj.rect):
            failed.play()
            return True

    def Pass(self, Obj):
        if (Obj.x < self.x or Obj.x > 1000) and self.isLanded == True:
            self.score += 1
            failed_2.play()
            self.isLanded = False


codemao = Cat()
cacti = Cacti()
bird = Bird()
while True:
    if keep_going:
        screen = pygame.display.set_mode([1000, 300])  # 设置窗体大小
        bg_color = (255, 255, 255)  # 设置RGB值为白色
        screen.fill(bg_color)  # 充填
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                content = "\n\n"+"{}月{}日 {}秒".format(strftime("%m", gmtime()), strftime("%d", gmtime(
                )), strftime("%H:%M:%S", gmtime()))+"：玩了"+str(codemao.num)+"次，得了"+str(codemao.score)+"分"
                with open(r"C:\Users\Administrator\Desktop\战绩.txt", "a") as f:
                    f.write(content)
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE or pygame.K_UP:
                    codemao.jump()

        screen.blit(codemao.pose_list[cnt % 29],
                    (codemao.get_position()))  # 绑定到窗口对应的位置
        screen.blit(cacti.img, (cacti.get_position()))  # 绑定到窗口对应的位置
        screen.blit(bird.img, (bird.get_position()))  # 绑定到窗口对应的位置
        if codemao.Cruch(cacti):
            screen.blit(failed_screen, (350, 60))
            keep_going = False
        if codemao.Cruch(bird):
            screen.blit(failed_screen, (350, 60))
            keep_going = False
        codemao.Pass(cacti)
        codemao.Pass(bird)
        text = font.render("第" + str(codemao.num) + "次得分：" +
                           str(codemao.score), True, (0, 0, 0))
        screen.blit(text, (800, 20))
        pygame.display.update()  # 更新界面
        timer.tick(60)
        cnt += 1

    if not keep_going:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                content = "\n\n"+"{}月{}日 {}秒".format(strftime("%m", gmtime()), strftime("%d", gmtime(
                )), strftime("%H:%M:%S", gmtime()))+"：玩了"+str(codemao.num)+"次，得了"+str(codemao.score)+"分"
                with open(r"C:\Users\Administrator\Desktop\战绩.txt", "a") as f:
                    f.write(content)
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    codemao.isjumping = False
                    codemao.isLanded = False
                    codemao.y = 100
                    cacti.x = 2000
                    bird.x = 2000 + random.randint(2000, 2500)
                    codemao.num += 1
                    keep_going = True

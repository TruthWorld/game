#导入库
import pygame
import random
class Bird():
    def __init__(self):
        self.bird_sprites = [pygame.image.load("{}.png".format(i)) for i in range(3)]
        self.a = 0
        self.bird_x = 50
        self.bird_y = 100
        self.down_speed = 0.4
        self.up_speed = 0
        self.bird_rect = self.bird_sprites[0].get_rect()

    def bird_speed(self):
        self.bird_rect.center = (self.bird_x,self.bird_y)
        self.up_speed -= self.down_speed
        self.bird_y -= self.up_speed
        if self.up_speed > 0:
            self.a = 0
        if self.up_speed < 0:
            self.a = 2

    def bird_crush(self):
        result_up = self.bird_rect.colliderect(new_wall.wall_up_rect)
        result_down = self.bird_rect.colliderect(new_wall.wall_down_rect)
        if result_up or result_down or self.bird_rect.top > 512:
            return True

class Wall():
    def __init__(self):
        self.wall_down = pygame.image.load("bottom.png")
        self.wall_up = pygame.image.load("top.png")
        self.wall_x = 288
        self.wall_y = 0
        self.gap = 150
        self.offset = random.randint(-100,100)
        self.wall_up_rect = self.wall_up.get_rect()
        self.wall_down_rect = self.wall_down.get_rect()

    def wall_update(self):
        self.wall_up_rect.center = (self.wall_x, 0 + self.offset)
        self.wall_down_rect.center = (self.wall_x, 370 + self.gap + self.offset)

        self.wall_x -= 2
        if self.wall_x < -80:
            self.wall_x = 288
            self.offset = random.randint(-100, 100)


class Wall2():
    def __init__(self):
        self.wall_down = pygame.image.load("bottom.png")
        self.wall_up = pygame.image.load("top.png")
        self.wall_x = 288
        self.wall_y = 0
        self.gap = 150
        self.offset = random.randint(-100, 100)
        self.wall_up_rect = self.wall_up.get_rect()
        self.wall_down_rect = self.wall_down.get_rect()

    def wall_update(self):
        self.wall_up_rect.center = (self.wall_x, 0 + self.offset)
        self.wall_down_rect.center = (
            self.wall_x, 370 + self.gap + self.offset)

        self.wall_x -= 2
        if self.wall_x < -80:
            self.wall_x = 288
            self.offset = random.randint(-100, 100)
# 游戏初始化，设置游戏标题，窗口等
pygame.init()
screen = pygame.display.set_mode((288, 512))
pygame.display.set_caption("翱翔吧！源码精灵")
# 获得游戏背景图片，源码精灵图片，初始坐标等
background = pygame.image.load("background.png")
new_bird = Bird()
new_wall = Wall()
new_wall2 = Wall2()
clock = pygame.time.Clock()
# pygame循环，源码精灵翱翔
keep_going = True
while keep_going:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            keep_going = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            new_bird.up_speed = 7
    
    new_bird.bird_speed()
    screen.blit(background,(0,0))
    screen.blit(new_bird.bird_sprites[new_bird.a], new_bird.bird_rect)
    screen.blit(new_wall.wall_up, new_wall.wall_up_rect)
    screen.blit(new_wall.wall_down, new_wall.wall_down_rect) 
    screen.blit(new_wall2.wall_up, new_wall2.wall_up_rect)
    screen.blit(new_wall2.wall_down, new_wall2.wall_down_rect)
    new_wall.wall_update()
    if new_bird.bird_crush():
        keep_going = False
    pygame.display.update()
    clock.tick(60)
# 退出游戏
pygame.quit()





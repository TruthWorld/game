import app

app.my_game()
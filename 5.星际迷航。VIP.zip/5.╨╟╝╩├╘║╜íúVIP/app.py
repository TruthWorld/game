import pgzrun
import random
import math
import time
#
WIDTH = 450
HEIGHT = 650
score = 0
we_score = 0#
speed = 2#
shoot = False#
t = 0#
attack = False
nttack = False
nttack2 = False
life = 5
game_state = 'a'#
guanka = "as"#
sheng_ming = 40
meet = "a"
sheng_ming2 = 60
meet2 = "a"
zhi = False
#
spaceship = Actor('ship', (200, 550))
diamond = Actor('di', (100, 200))
enermy = Actor('e', (100, 200))
bullet = Actor('b', (1000, 2000))
bullet_red = Actor('r', (200, -100))
heart = Actor('h', (300, -5000))
gk1 = Actor('1', (60, 100))
gk2 = Actor('2', (235, 100))
gk3 = Actor('3', (395, 100))
gk4 = Actor('4', (60, 250))
gk5 = Actor('5', (235, 250))
dig = Actor('12', (235, 100))
dog = Actor('13', (235, 100))
br = Actor('br', (1000,10000000))
br2 = Actor('br2', (1000, 100000000))
da = Actor('d', (235, 100))
xiao = Actor('x', (235, 100))
da2 = Actor('d2', (235, 100))
xiao2 = Actor('x2', (235, 100))
#


def draw():
    global game_state, guanka, shoot, score, life,sheng_ming,sheng_ming2,meet,meet2,zhi
    if game_state == 'a':
        screen.blit('sp', (0, 0))
        screen.draw.text('spacecraft', (115, 260), fontsize=60)
        screen.draw.text('press space to state!', (85, 320), fontsize=40)
        if keyboard.space:
            game_state = 'b'
    elif game_state == 'b':
        screen.blit('sp', (0, 0))
        gk1.draw()
        gk2.draw()
        gk3.draw()
        gk4.draw()
        gk5.draw()

    elif game_state == 'c':
        screen.blit('sp', (0, 0))
        screen.draw.text('game to!', (90, 230), color='red', fontsize=100)
        score = 0
        life = 5
        sheng_ming = 40
        meet = "a"
        sheng_ming2 = 60
        meet2 = "a"
        zhi = False
        if keyboard.space:
            game_state = 'b'
    
#
    if guanka == 'z':
        screen.blit('sp', (0, 0))
        screen.draw.text('score:' + str(score), (10, 10), fontsize=40)
        screen.draw.text('life:' + str(life), (370, 10), fontsize=30)
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
#
    elif guanka == 'x':
        screen.blit('sp', (0, 0))
        screen.draw.text('score:' + str(score), (10, 10), fontsize=40)
        screen.draw.text('life:' + str(life), (370, 10), fontsize=30)
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
#
    elif guanka == 'c':
        screen.blit('sp', (0, 0))
        screen.draw.text('score:' + str(score), (10, 10), fontsize=40)
        screen.draw.text('life:' + str(life), (370, 10), fontsize=30)
        if score > 100 and meet == 'a':
            screen.draw.text('sheng_ming:' + str(sheng_ming),
                            (205, 620), fontsize=40)
            dog.draw()
        elif meet == 'b':
            xiao.draw()
            da.draw()
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
        if meet == 'a':
            br.draw()
#
    elif guanka == 'v':
        screen.blit('sp', (0, 0))
        screen.draw.text('score:' + str(score), (10, 10), fontsize=40)
        screen.draw.text('life:' + str(life), (370, 10), fontsize=30)
        if score > 100 and meet == 'a':
            screen.draw.text('sheng_ming:' + str(sheng_ming),
                            (205, 620), fontsize=40)
            dig.draw()
        elif meet == 'b':
            xiao.draw()
            da.draw()
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
        if meet == 'a':
            br.draw()
#
    elif guanka == 'b':
        screen.blit('sp', (0, 0))
        screen.draw.text('score:' + str(score), (10, 10), fontsize=40)
        screen.draw.text('life:' + str(life), (370, 10), fontsize=30)
        if score > 100 and meet == 'a':
            screen.draw.text('sheng_ming:' + str(sheng_ming),
                            (205, 620), fontsize=40)
            dog.draw()
        elif meet == 'b':
            xiao.draw()
            da.draw()
        if score > 200 and meet2 == 'a'and zhi == True:
            screen.draw.text('sheng_ming:' + str(sheng_ming2),
                            (205, 620), fontsize=40)
            dig.draw()
        elif meet2 == 'b':
            xiao2.draw()
            da2.draw()
        spaceship.draw()
        diamond.draw()
        enermy.draw()
        bullet.draw()
        bullet_red.draw()
        heart.draw()
        if meet == 'a':
            br.draw()
        if meet2 == 'a':
            br2.draw()

#
def on_mouse_down(pos):
    global guanka
    if gk1.collidepoint(pos):
        guanka = "z"
    elif gk2.collidepoint(pos):
        guanka = "x"
    elif gk3.collidepoint(pos):
        guanka = "c"
    elif gk4.collidepoint(pos):
        guanka = "v"
    elif gk5.collidepoint(pos):
        guanka = "b"
#

def place_object(obj):
    obj.x = random.randint(20, WIDTH - 20)
    obj.y = random.randint(-200, -40)
#


def spaceship_collide(obj):
    global  game_state,life,guanka,meet,sheng_ming,meet2
    if spaceship.collidepoint(obj.pos):
        place_object(obj)
        life -= 1
        if life < 0:
            guanka = 'as'
            game_state = 'c'
            meet = "a"
            sheng_ming = 30
            sheng_ming2 = 30
            meet2 = "a"

#


def update():
    global score, guanka, shoot, t, attack, game_state, life, nttack, nttack2, sheng_ming, meet, sheng_ming2, meet2,zhi 
    if guanka == 'z':
        enermy.y += speed+1
        enermy.x = WIDTH / 2 * (1 + math.sin(t))
        t += 0.02
        diamond.y += speed+3
        heart.y += speed+3
        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        if keyboard.right:
            spaceship.x += 5
        if keyboard.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

            
        if keyboard.a:
            shoot = True
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > 20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True
        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False
        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            place_object(bullet)
            score += 10
            

        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            score += 10
        spaceship_collide(enermy)
        spaceship_collide(bullet_red)
        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
        if spaceship.collidepoint(heart.pos):
            life += 1
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
#
    if guanka == 'x':
        enermy.y += speed +3
        enermy.x = WIDTH / 2 * (1 + math.sin(t))
        t += 0.02
        diamond.y += speed+3
        heart.y += speed+3
        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        if keyboard.right:
            spaceship.x += 5
        if keyboard.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

        if keyboard.a:
            shoot = True
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > 20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True
        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False
        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            place_object(bullet)
            score += 10

        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            score += 10
        spaceship_collide(enermy)
        spaceship_collide(bullet_red)
        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
        if spaceship.collidepoint(heart.pos):
            life += 0.5
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
#
    if guanka == 'c':
        if meet == 'b':
            xiao.y += 5
            da.y += 5
        if meet == 'a':
            dog.x += 1 
            if dog.x == 450:
                dog.x = 0
        enermy.y += speed - 1
        enermy.x = WIDTH / 2 * (1 + math.sin(t))
        t += 0.02
        diamond.y += speed+3
        heart.y += speed
        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        if keyboard.right:
            spaceship.x += 5
        if keyboard.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

        if keyboard.a:
            shoot = True
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > 20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True
        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False
#
        if meet == 'a':
            if br.y >0 and nttack == False:
                if dog.x - spaceship.x < 20 and \
                    dog.x - spaceship.x > -20:
                    br.pos = dog.x, dog.y + 20
                    nttack = True
            if nttack:
                if br.y < HEIGHT + 500:
                    br.y += speed + 6
                else:
                    nttack = False
            if dog.collidepoint(bullet.pos):
                place_object(bullet)
                sheng_ming -= 1
                score += 10
            if sheng_ming == 0:
                meet = 'b'
        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            place_object(bullet)
            score += 10
        
        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            score += 10
        spaceship_collide(enermy)
        spaceship_collide(bullet_red)
        spaceship_collide(br)
        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
        if spaceship.collidepoint(heart.pos):
            life += 1
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)

#
    if guanka == 'v':
        if meet == 'b':
            xiao.y += 5
            da.y += 5
        if meet == 'a':
            dig.x += 1
            if dig.x == 450:
                dig.x = 0
        enermy.y += speed - 1
        enermy.x = WIDTH / 2 * (1 + math.sin(t))
        t += 0.02
        diamond.y += speed+3
        heart.y += speed
        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        if keyboard.right:
            spaceship.x += 5
        if keyboard.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

        if keyboard.a:
            shoot = True
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > 20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True
        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False
#
        if meet == 'a':
            if br.y > 0 and nttack == False:
                if dig.x - spaceship.x < 20 and \
                        dig.x - spaceship.x > -20:
                    br.pos = dig.x, dig.y + 20
                    nttack = True
            if nttack:
                if br.y < HEIGHT + 500:
                    br.y += speed + 6
                else:
                    nttack = False
            if dig.collidepoint(bullet.pos):
                place_object(bullet)
                sheng_ming -= 1
                score += 10
            if sheng_ming == 0:
                meet = 'b'
        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            place_object(bullet)
            score += 10

        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            score += 10
        spaceship_collide(enermy)
        spaceship_collide(bullet_red)
        spaceship_collide(br)
        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
        if spaceship.collidepoint(heart.pos):
            life += 1
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)

#
    if guanka == 'b':
        if meet == 'b':
            xiao.y += 5
            da.y += 5
        if meet == 'a':
            dog.x += 1
            if dog.x == 450:
                dog.x = 0
        #
        if meet2 == 'b':
            xiao2.y += 5
            da2.y += 5
        if meet2 == 'a':
            dig.x += 1
            if dig.x == 450:
                dig.x = 0
        enermy.y += speed + 1
        enermy.x = WIDTH / 2 * (1 + math.sin(t))
        t += 0.02
        diamond.y += speed+3
        heart.y += speed+3
        if enermy.y > HEIGHT + 100:
            place_object(enermy)
        if diamond.y > HEIGHT + 100:
            place_object(diamond)

        if keyboard.left:
            spaceship.x -= 5
        if keyboard.right:
            spaceship.x += 5
        if keyboard.x < 0:
            spaceship.x = 0
        elif spaceship.x > WIDTH:
            spaceship.x = WIDTH

        if keyboard.a:
            shoot = True
            init_pos = spaceship.x, spaceship.y - 60
            bullet.pos = init_pos[0], init_pos[1]
        if shoot:
            if bullet.y > 20:
                bullet.y -= 10
            else:
                shoot = False
                bullet.x = -160

        if enermy.y > 0 and attack == False:
            if enermy.x - spaceship.x < 20 and \
                    enermy.x - spaceship.x > -20:
                bullet_red.pos = enermy.x, enermy.y + 20
                attack = True
        if attack:
            if bullet_red.y < HEIGHT + 500:
                bullet_red.y += speed + 2
            else:
                attack = False

        if meet == 'a':
            if br.y > 0 and nttack2 == False:
                if dig.x - spaceship.x < 20 and \
                        dig.x - spaceship.x > -20:
                    br.pos = dig.x, dig.y + 20
                    nttack2 = True
            if nttack2:
                if br.y < HEIGHT + 500:
                    br.y += speed + 6
                else:
                    nttack2 = False
            if dig.collidepoint(bullet.pos):
                place_object(bullet)
                sheng_ming -= 1
                score += 10
            if sheng_ming == 0:
                meet = 'b'
                zhi = True
        if meet2 == 'a':
            if br2.y > 0 and nttack == False:
                if dog.x - spaceship.x < 20 and \
                        dog.x - spaceship.x > -20:
                    br2.pos = dog.x, dog.y + 20
                    nttack = True
            if nttack:
                if br2.y < HEIGHT + 500:
                    br2.y += speed + 6
                else:
                    nttack = False
            if dog.collidepoint(bullet.pos):
                place_object(bullet)
                sheng_ming2 -= 1
                score += 10
            if sheng_ming2 == 0:
                meet2 = 'b'
        if enermy.collidepoint(bullet.pos):
            place_object(enermy)
            place_object(bullet)
            score += 10

        if spaceship.collidepoint(diamond.pos):
            place_object(diamond)
            score += 10
        spaceship_collide(enermy)
        spaceship_collide(bullet_red)
        spaceship_collide(br)
        spaceship_collide(br2)
        if heart.y > HEIGHT + 100:
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)
        if spaceship.collidepoint(heart.pos):
            life += 1
            heart.x = random.randint(50, WIDTH - 50)
            heart.y = random.randint(-10000, -5000)

#



pgzrun.go()

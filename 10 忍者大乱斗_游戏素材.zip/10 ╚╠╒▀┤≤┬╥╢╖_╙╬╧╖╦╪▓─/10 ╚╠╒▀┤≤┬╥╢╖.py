import pgzrun

WIDTH = 1280
HEIGHT = 720
ninja = [Actor('lucas_r', (200, 540)),
         Actor('roger_l', (1080, 540))]  # 忍者角色列表
dart = [Actor('dart', (-50, 100)),
        Actor('dart', (-50, 100))]  # 飞镖角色列表

jump_speed = [10, 10]  # 跳跃速度
dart_speed = [18, -18]  # 飞镖移动速度
jump = [False, False]
shoot = [False, False]
init_pos = [(100, 100), (100, 100)]  # 飞镖发射时的初始位置
hp = [10, 10]  # 生命值
game_state = 'start'


def draw():
    global game_state, hp
    # 设置开始画面
    if game_state == 'start':
        screen.blit('background', (0, 0))
        screen.blit('cover', (320, 210))
        if keyboard.space:
            game_state = 'play'
    # 游戏开始后，显示角色和生命值
    elif game_state == 'play':
        screen.blit('background', (0, 0))
        text_pos = [(160, 30), (WIDTH - 260, 30)]
        for i in range(2):
            ninja[i].draw()
            dart[i].draw()
            screen.draw.text('HP: ' + str(hp[i]), text_pos[i],
                             color='red', fontsize=60)
    # 显示游戏结束画面
    else:
        screen.blit('background', (0, 0))
        for i in range(2):
            ninja[i].draw()
        screen.draw.text('GAME OVER!', (495, 270),
                         color='red', fontsize=70)
        # 显示胜者信息
        winner = 'Ninja Lucas '
        if hp[1] > hp[0]:
            winner = 'Ninja Roger '
        screen.draw.text(winner + 'wins',
                         (510, 340), fontsize=50)
        screen.draw.text('press SPACE to restart',
                         (520, 390), fontsize=36)
        # 按空格键重新开始游戏
        if keyboard.space:
            game_state = 'play'
            hp = [10, 10]


def attack(index):
    global shoot, init_pos, dart
    # 设置飞镖发射时的初始位置
    init_pos[index] = ninja[index].x, ninja[index].y + 10
    dart[index].pos = init_pos[index]
    shoot[index] = True


# 检测忍者与飞镖的碰撞
def collision_detect(ninj, dar, index):
    global hp
    if ninj.collidepoint(dar.pos):
        if hp[index] > 0:
            hp[index] -= 1
            sounds.hit.play()
        dar.x = WIDTH + 200
        dar.y = HEIGHT - 100


def update():
    global game_state, jump, init_pos, jump_speed, shoot, hp
    if game_state == 'play':
        # 按键控制忍者移动
        if keyboard.d:
            ninja[0].x += 6
        elif keyboard.a:
            ninja[0].x -= 6
        if keyboard.right:
            ninja[1].x += 6
        elif keyboard.left:
            ninja[1].x -= 6
        # 按键控制忍者跳跃
        if keyboard.w:
            jump[0] = True
        if keyboard.up:
            jump[1] = True
        # 按键控制忍者发射飞镖
        if keyboard.v:
            attack(0)
        if keyboard.m:
            attack(1)

        for i in range(2):
            if jump[i]:
                # 忍者跳跃，跳跃速度逐渐减小
                if ninja[i].y <= 540:
                    ninja[i].y -= jump_speed[i]
                    jump_speed[i] -= 0.3
                # 忍者落到地面，y 坐标不再变化
                else:
                    ninja[i].y = 540
                    jump[i] = False
                    jump_speed[i] = 12
            if shoot[i]:
                # 飞镖在屏幕内时，飞镖移动并旋转
                if dart[i].x < WIDTH + 50 and dart[i].x > -50:
                    dart[i].x += dart_speed[i]
                    dart[i].angle += 8

            if ninja[i].x < 50:
                ninja[i].x = 50
            elif ninja[i].x > WIDTH - 50:
                ninja[i].x = WIDTH - 50
            # 生命值为 0 时，游戏结束
            if hp[i] == 0:
                game_state = 'game over'

        # 检测飞镖与忍者的碰撞
        collision_detect(ninja[1], dart[0], 1)
        collision_detect(ninja[0], dart[1], 0)


pgzrun.go()

import pgzrun
import random

WIDTH = 1280
HEIGHT = 720
ninja = [Actor('lucas_r', (200, 540)),
         Actor('roger_l', (1080, 540))]
dart = [Actor('dart', (-50, 100)),
        Actor('dart', (-50, 100))]
hp_bar = [Actor('hpl10', (370, 60)),
          Actor('hpr10', (910, 60))]
character = [Actor('ninja_head_l', (100, 70)),
             Actor('ninja_head_r', (1180, 70))]
heart = Actor('heart', (640, -2000))
mp_bar = [Actor('mpl3', (260, 90)),
          Actor('mpr3', (1020, 90))]

jump_speed = [10, 10]
dart_speed = [18, -18]
jump = [False, False]
shoot = [False, False]
init_pos = [(100, 100), (100, 100)]
hp = [10, 10]
game_state = 'start'
direction = ['R', 'L']
mp = [12, 12]


def draw():
    global game_state, hp, mp
    if game_state == 'start':
        screen.blit('background', (0, 0))
        screen.blit('cover', (320, 210))
        if keyboard.space:
            game_state = 'play'
    elif game_state == 'play':
        screen.blit('background', (0, 0))
        for i in range(2):
            ninja[i].draw()
            dart[i].draw()
            hp_bar[i].draw()
            character[i].draw()
            mp_bar[i].draw()
        heart.draw()
    else:
        screen.blit('background', (0, 0))
        for i in range(2):
            ninja[i].draw()
        screen.draw.text('GAME OVER!', (495, 270),
                         color='red', fontsize=70)
        winner = 'Ninja Lucas '
        if hp[1] > hp[0]:
            winner = 'Ninja Roger '
        screen.draw.text(winner + 'wins',
                         (510, 340), fontsize=50)
        screen.draw.text('press SPACE to restart',
                         (520, 390), fontsize=36)
        if keyboard.space:
            game_state = 'play'
            hp = [10, 10]
            hp_bar[0].image = 'hpl10'
            hp_bar[1].image = 'hpr10'
            mp = [12, 12]
            mp_bar[0].image = 'mpl3'
            mp_bar[1].image = 'mpr3'


def attack(index):
    global shoot, init_pos, dart, direction, dart_speed
    init_pos[index] = ninja[index].x, ninja[index].y + 10
    dart[index].pos = init_pos[index]
    shoot[index] = True
    if direction[index] == 'R':
        dart_speed[index] = 18
    else:
        dart_speed[index] = -18


def collision_detect(ninj, dar, index):
    global hp
    if ninj.collidepoint(dar.pos):
        if hp[index] > 0:
            hp[index] -= 1
            sounds.hit.play()
        dar.x = WIDTH + 200
        dar.y = HEIGHT - 100
        if index == 0:
            hp_bar[index].image = 'hpl' + str(hp[index])
        else:
            hp_bar[index].image = 'hpr' + str(hp[index])


def update():
    global game_state, jump, init_pos, jump_speed, shoot, hp, \
        dart_speed, direction
    if game_state == 'play':
        if keyboard.d:
            ninja[0].x += 6
            ninja[0].image = 'lucas_r'
            direction[0] = 'R'
        elif keyboard.a:
            ninja[0].x -= 6
            ninja[0].image = 'lucas_l'
            direction[0] = 'L'
        if keyboard.right:
            ninja[1].x += 6
            ninja[1].image = 'roger_r'
            direction[1] = 'R'
        elif keyboard.left:
            ninja[1].x -= 6
            ninja[1].image = 'roger_l'
            direction[1] = 'L'

        if keyboard.w:
            jump[0] = True
        if keyboard.up:
            jump[1] = True

        if keyboard.v:
            dart[0].image = 'dart'
            attack(0)
        if keyboard.m:
            dart[1].image = 'dart'
            attack(1)

        if keyboard.r:
            if mp[0] >= 12:
                dart[0].image = 'big_dart'
                mp[0] = 0
                mp_bar[0].image = 'mpl0'
                attack(0)
        if keyboard.j:
            if mp[1] >= 12:
                dart[1].image = 'big_dart'
                mp[1] = 0
                mp_bar[1].image = 'mpr0'
                attack(1)

        for i in range(2):
            if jump[i]:
                if ninja[i].y <= 540:
                    ninja[i].y -= jump_speed[i]
                    jump_speed[i] -= 0.3
                else:
                    ninja[i].y = 540
                    jump[i] = False
                    jump_speed[i] = 12
            if shoot[i]:
                if dart[i].x < WIDTH + 50 and dart[i].x > -50:
                    dart[i].x += dart_speed[i]
                    dart[i].angle += 8

            if ninja[i].x < 50:
                ninja[i].x = 50
            elif ninja[i].x > WIDTH - 50:
                ninja[i].x = WIDTH - 50

            if hp[i] == 0:
                game_state = 'game over'

        collision_detect(ninja[1], dart[0], 1)
        collision_detect(ninja[0], dart[1], 0)

        heart.y += 6
        if heart.y > HEIGHT + 50:
            heart.y = random.randint(-5000, -2000)

        for i in range(2):
            if ninja[i].collidepoint(heart.pos):
                if hp[i] < 10:
                    hp[i] += 1
                    if i == 0:
                        hp_bar[i].image = 'hpl' + str(hp[i])
                    else:
                        hp_bar[i].image = 'hpr' + str(hp[i])
                    sounds.powerup.play()
                heart.y = random.randint(-5000, -2000)

            if mp[i] < 12:
                mp[i] += 0.01
                if i == 0:
                    mp_bar[i].image = 'mpl' + str(int(mp[i] // 4))
                else:
                    mp_bar[i].image = 'mpr' + str(int(mp[i] // 4))

        if keyboard.f:
            if mp[0] >= 12:
                mp[0] = 0
                if direction[0] == 'L':
                    ninja[0].x -= 400
                else:
                    ninja[0].x += 400
        if keyboard.n:
            if mp[1] >= 12:
                mp[1] = 0
                if direction[1] == 'L':
                    ninja[1].x -= 400
                else:
                    ninja[1].x += 400


pgzrun.go()

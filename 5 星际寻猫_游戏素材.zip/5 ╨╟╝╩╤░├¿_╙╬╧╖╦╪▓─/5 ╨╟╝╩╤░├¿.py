import pgzrun
from random import randint

WIDTH = 800
HEIGHT = 600
get_cat = False  # False 表示没找到猫咪

astronaut = Actor("astronaut")
astronaut.pos = 330, 330
cat = Actor("cat")
# 随机设置猫咪的位置
cat.pos = randint(100, 700), randint(100, 500)
# 播放雷达声
music.play('dududu')


def draw():
    screen.blit('background', (0, 0))  # 设置背景
    astronaut.draw()
    # 如果找到猫咪，猫咪显示
    if get_cat:
        cat.draw()


def update():
    global get_cat
    if get_cat == False:
        # 按键 A 按下，阿短左移
        if keyboard.a:
            astronaut.x -= 2
        # 按键 d 按下，阿短右移
        elif keyboard.d:
            astronaut.x += 2
        if keyboard.w:
            astronaut.y -= 2
        elif keyboard.s:
            astronaut.y += 2
        # 计算阿短与猫咪之间的距离
        distance = astronaut.distance_to(cat)
        # 如果距离小于等于 400，根据距离调整音量大小
        if distance <= 400:
            music.set_volume(1 - distance / 450)
        # 否则音量大小设置为 0.1
        else:
            music.set_volume(0.1)
        # 如果距离小于 100 且按下 U 键，猫咪找到，播放胜利音乐
        if distance < 100 and keyboard.u:
            get_cat = True
            music.pause()
            music.play_once('success')

pgzrun.go()

import pgzrun
from random import randint

WIDTH = 800
HEIGHT = 600
get_cat = False
time_left = 15
game_over = False
game_start = False

astronaut = Actor("astronaut")
astronaut.pos = 330, 330
cat = Actor("cat")
cat.pos = randint(100, 700), randint(100, 500)


def draw():
    global game_start
    if game_start:
        screen.blit('background', (0, 0))
        astronaut.draw()
        if get_cat:
            cat.draw()

        screen.draw.text("Time Left: " + str(time_left),
                         color="white", topleft=(10, 10), fontsize=50)
        if game_over:
            screen.draw.text("You lost the cat",
                             topleft=(150, 260), fontsize=100)  # 在屏幕显示You lost the cat的文字
            music.pause()
    else:
        screen.blit('background', (0, 0))
        screen.draw.text("Space Cat", topleft=(280, 240), fontsize=80)
        screen.draw.text("Press space to start",
                         topleft=(220, 300), fontsize=60)
        if keyboard.space:
            game_start = True
            music.play('dududu')
            clock.schedule_interval(update_time_left, 1.0)


def update():
    global get_cat, game_start
    if game_start:
        if get_cat == False:
            if keyboard.a:
                astronaut.x -= 2
            elif keyboard.d:
                astronaut.x += 2
            if keyboard.w:
                astronaut.y -= 2
            elif keyboard.s:
                astronaut.y += 2

            distance = astronaut.distance_to(cat)
            if distance <= 400:
                music.set_volume(1 - distance / 450)
            else:
                music.set_volume(0.1)

            if distance < 100 and keyboard.u:
                get_cat = True
                music.pause()
                music.play_once('success')


def update_time_left():
    global time_left, get_cat, game_over
    if get_cat == False:  # 判断是否抓到猫咪，没有抓到的话才开始计数
        if time_left:
            time_left -= 1  # 计数逐渐减少
        else:
            game_over = True  # 设置变量代表游戏结束


pgzrun.go()

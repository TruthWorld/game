import pgzrun
import random

WIDTH = 450
HEIGHT = 650
game_state = 'start'
# 方块下落速度
y_speed = 11
score = 0
# 计数列表
count_list = [0, 0, 0]
# 新建下落方块角色列表
block = [Actor('blue_block1'), Actor('orange_block1'),
         Actor('red_block1')]
# 新建字母方块角色列表
block_bottom = [Actor('blue_block2'), Actor('orange_block2'),
                Actor('red_block2')]
# 获取方块高度
block_height = block[0].height
# 设置字母方块造型列表
animate_image = ['blue_block2', 'orange_block2', 'red_block2',
                 'blue_block3', 'orange_block3', 'red_block3']
# 设置下落方块和字母方块初始位置
for i in range(3):
    block[i].x = 75 + 150 * i
    block[i].y = -150 * i
    block_bottom[i].x = 75 + 150 * i
    block_bottom[i].y = HEIGHT - 100


def draw():
    global game_state, score
    # 设置开始画面
    if game_state == 'start':
        screen.fill('gold')
        screen.draw.text('Music Block', (120, 260), fontsize=50)
        screen.draw.text('Press SPACE to start!',
                         (120, 300), fontsize=30)
        if keyboard.space:
            game_state = 'play'
            music.play('bg_music1')
    # 游戏开始后，显示角色
    elif game_state == 'play':
        screen.fill('gold')
        # 画出 3 条直线
        for i in range(3):
            screen.draw.filled_rect(
                Rect((73 + 150 * i, 0, 4, HEIGHT)), (150, 150, 150))
            block[i].draw()
            block_bottom[i].draw()
        screen.draw.text('score: ' + str(score), (10, 10), fontsize=40)


def update():
    global game_state, y_speed, score, count_list
    if game_state == 'play':
        for i in range(3):
            block[i].y += y_speed
            # 检测方块碰撞
            if block[i].colliderect(block_bottom[i]):
                key = 6
                if keyboard.a:
                    key = 0
                elif keyboard.s:
                    key = 1
                elif keyboard.d:
                    key = 2
                # 如果方块碰撞时，按下了相应按键，得分增加
                if key == i:
                    score += 10
                    block[i].y = random.randint(-500, -50)
                    # 改变字母方块造型
                    block_bottom[i].image = animate_image[i + 3]
                    count_list[i] = 1
            # 通过计数来确定字母方块造型切换的时刻
            if count_list[i] > 0:
                count_list[i] += 1
                if count_list[i] > 10:
                    count_list[i] = 0
                    block_bottom[i].image = animate_image[i]
            # 如果下落方块移出屏幕，重置它的位置
            if block[i].y > HEIGHT + block_height / 2:
                block[i].y = random.randint(-500, -50)

            if y_speed < 24:
                # 得分每增加 800，方块下落速度加 1
                y_speed = 12 + score // 800


pgzrun.go()

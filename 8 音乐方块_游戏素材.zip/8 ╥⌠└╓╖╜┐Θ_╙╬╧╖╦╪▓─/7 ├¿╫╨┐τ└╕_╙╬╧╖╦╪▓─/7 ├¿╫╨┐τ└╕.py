import pgzrun
# 导入随机模块
from random import randint

WIDTH = 640
HEIGHT = 360
score = 0
# 设置游戏状态
game_state = 'start'
# 设置障碍方块移动速度
move_speed = 5
# 猫仔走路造型切换计数
count = 0
# 猫仔是否跳跃
jump = False
# 猫仔跳跃的状态
jump_state = 'up'

# 猫仔角色
cat = Actor("mao_walk1", (100, HEIGHT - 58))
# 设置障碍方块的尺寸
box = Rect(WIDTH + 200, HEIGHT - 50, 40, 50)


def draw():
    # 设置开始画面
    if game_state == 'start':
        screen.blit('rainbow', (0, 0))
        cat.draw()
        screen.draw.text("Hurdle", color="dodgerblue",
                         center=(WIDTH / 2, 150), fontsize=70)
        screen.draw.text("Press any key to start",
                         color="dodgerblue",
                         center=(WIDTH / 2, 210), fontsize=40)
    # 设置游戏画面
    else:
        screen.blit('rainbow', (0, 0))
        # 显示橙色障碍方块
        screen.draw.filled_rect(box, 'orange')
        cat.draw()
        screen.draw.text("Score: " + str(score),
                         color="dodgerblue",
                         topleft=(10, 10), fontsize=40)
        # 游戏结束画面
        if game_state == 'game over':
            screen.draw.text("Game Over", color="dodgerblue",
                             center=(WIDTH / 2, HEIGHT / 2),
                             fontsize=100)


# 按下任意键开始游戏
def on_key_down():
    global game_state
    if game_state == 'start':
        game_state = 'play'


# 点击鼠标跳跃
def on_mouse_down():
    global jump
    if game_state == 'play':
        jump = True


def cat_walk():
    global count
    # cat_walk() 程序每运行 9 次，猫仔变换一次走路姿势
    if count == 9:
        count = 0
        if cat.image == "mao_walk1":
            cat.image = "mao_walk2"
        else:
            cat.image = "mao_walk1"
    else:
        count += 1


def cat_jump():
    global jump, jump_state
    # 猫仔跳跃时改变造型
    cat.image = "mao_jump"
    # 跳跃状态为 up 时，猫仔上升
    if jump_state == 'up':
        cat.y -= 5
        # 到达最高点，猫仔跳跃状态改为 down
        if cat.y <= HEIGHT / 2 - 10:
            jump_state = 'down'
    # 跳跃状态为 down 时，猫仔下降
    elif jump_state == 'down':
        cat.y += 5
        # 到达地面，猫仔不再下降
        if cat.y == HEIGHT - 58:
            jump = False
            jump_state = 'up'


def update():
    global score, game_state, move_speed
    # 游戏进行中
    if game_state == 'play':
        # 根据 jump 变量让猫仔跳跃或移动
        if jump:
            cat_jump()
        else:
            cat_walk()

        box.x -= move_speed
        # 如果障碍方块移出屏幕，则重置它的位置
        if box.x < -30:
            score += 1
            box.x = randint(700, 1000)
            move_speed += 0.2
        # 如果障碍方块碰到了猫仔，则游戏结束
        if box.collidepoint(cat.x + 30, cat.y + 55) \
                or box.collidepoint(cat.x - 23, cat.y + 40):
            game_state = 'game over'
            cat.image = "mao_end"

pgzrun.go()

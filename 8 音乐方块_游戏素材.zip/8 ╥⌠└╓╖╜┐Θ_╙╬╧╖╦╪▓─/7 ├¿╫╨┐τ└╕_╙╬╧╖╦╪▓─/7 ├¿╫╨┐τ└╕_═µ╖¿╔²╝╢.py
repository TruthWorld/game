import pgzrun
from random import randint

WIDTH = 640
HEIGHT = 360
score = 0
game_state = 'start'
move_speed = 5
count = 0
jump = False
jump_state = 'up'
coin_collected = 0

coin = Actor("coin")
coin.pos = 1000, 300
cat = Actor("mao_walk1", (100, HEIGHT - 58))
box = Rect(WIDTH + 200, HEIGHT - 50, 40, 50)


def draw():
    if game_state == 'start':
        screen.blit('rainbow', (0, 0))
        cat.draw()
        screen.draw.text("Mao Jump", color="dodgerblue",
                         center=(WIDTH / 2, 150), fontsize=70)
        screen.draw.text("Press any key to start",
                         color="dodgerblue",
                         center=(WIDTH / 2, 210), fontsize=40)
    else:
        screen.blit('rainbow', (0, 0))
        screen.draw.filled_rect(box, 'orange')
        cat.draw()
        coin.draw()
        screen.draw.text("Coin: " + str(coin_collected), color="dodgerblue",
                         topright=(WIDTH - 10, 10), fontsize=40)
        screen.draw.text("Score: " + str(score),
                         color="dodgerblue",
                         topleft=(10, 10), fontsize=40)
        if game_state == 'game over':
            screen.draw.text("Game Over", color="dodgerblue",
                             center=(WIDTH / 2, HEIGHT / 2),
                             fontsize=100)


def on_key_down():
    global game_state
    if game_state == 'start':
        game_state = 'play'


def on_mouse_down():
    global jump, jump_speed
    if game_state == 'play':
        jump = True


def cat_walk():
    global count
    if count == 9:
        count = 0
        if cat.image == "mao_walk1":
            cat.image = "mao_walk2"
        else:
            cat.image = "mao_walk1"
    else:
        count += 1


def cat_jump():
    global jump, jump_state
    cat.image = "mao_jump"
    if jump_state == 'up':
        cat.y -= 5
        if cat.y <= HEIGHT / 2 - 10:
            jump_state = 'down'
    elif jump_state == 'down':
        cat.y += 5
        if cat.y == HEIGHT - 58:
            jump = False
            jump_state = 'up'


def update():
    global score, game_state, move_speed, coin_collected, box
    if game_state == 'play':
        if jump:
            cat_jump()
        else:
            cat_walk()
        box.x -= move_speed
        if box.x < -30:
            height = randint(40, 80)
            box = Rect(randint(700, 1000), HEIGHT - height,
                       randint(20, 60), height)
            box.x = randint(700, 1000)
            score += 1
            move_speed += 0.2
        if box.collidepoint(cat.x + 30, cat.y + 55) \
                or box.collidepoint(cat.x - 23, cat.y + 40):
            game_state = 'game over'
            cat.image = 'mao_end'

        coin.x -= move_speed
        if cat.colliderect(coin) or coin.x < 0:
            if coin.x > 0:
                coin_collected += 1
                sounds.coin.play()
            coin.x = randint(800, 3000)
            coin.y = randint(150, 320)

pgzrun.go()

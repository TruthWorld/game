import pgzrun
import random

WIDTH = 450
HEIGHT = 650
score = 0
# 设置皮球在 x、y 方向的移动速度
x_speed, y_speed = 5, -5
# 设置平板移动速度
move_speed = 6
# 设置游戏状态
game_state = 'start'
# 创建角色，设置初始位置
ball = Actor('ball', (300, 300))
coin = Actor('coin', (225, 150))
panel = Actor('panel', (225, 500))


def draw():
    global game_state
    # 设置游戏开始画面
    if game_state == 'start':
        screen.fill('gold')
        screen.draw.text('Bounce Ball', (136, 260), fontsize=50)
        screen.draw.text('Press SPACE to start!', (132, 310),
                         fontsize=30)
        # 按空格键切换游戏状态
        if keyboard.space:
            game_state = 'play'
    # 游戏进行中，显示得分和角色
    elif game_state == 'play':
        screen.fill('gold')
        screen.draw.text('score: ' + str(score), (10, 10),
                         fontsize=30)
        panel.draw()
        ball.draw()
        coin.draw()
    # 游戏结束，显示结束画面
    else:
        screen.fill('gold')
        panel.draw()
        ball.draw()
        coin.draw()
        screen.draw.text('Game Over', (136, 260),
                         color='red', fontsize=50)
        screen.draw.text('Your Score: ' + str(score),
                         (140, 310), fontsize=40)


def update():
    global game_state, score, x_speed, y_speed
    if game_state == 'play':
        # 皮球移动
        ball.x += x_speed
        ball.y += y_speed
        # 皮球碰到左边缘或右边缘反弹
        if ball.x < 25 or ball.x > WIDTH - 25:
            x_speed = - x_speed
            ball.x += x_speed
        if ball.y < 25:
            y_speed = - y_speed
            ball.y += y_speed
        # 皮球碰到下边缘，游戏结束
        elif ball.y > HEIGHT - 30:
            game_state = 'game over'
        # WSAD 键控制平板上下左右移动
        if keyboard.a:
            panel.x -= move_speed
        elif keyboard.d:
            panel.x += move_speed
        elif keyboard.w:
            panel.y -= move_speed
        elif keyboard.s:
            panel.y += move_speed
        # 皮球碰到平板反弹
        if panel.colliderect(ball):
            y_speed = - y_speed
        # 皮球碰到金币，得分 +1，金币移到随机位置
        if coin.collidepoint(ball.pos):
            score += 1
            coin.x = random.randint(30, WIDTH - 30)
            coin.y = random.randint(30, HEIGHT / 2)


pgzrun.go()

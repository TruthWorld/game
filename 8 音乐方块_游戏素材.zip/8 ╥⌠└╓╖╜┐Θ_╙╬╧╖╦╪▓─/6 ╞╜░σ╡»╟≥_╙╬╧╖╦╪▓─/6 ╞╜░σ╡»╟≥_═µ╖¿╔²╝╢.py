import pgzrun
import random

WIDTH = 450
HEIGHT = 650
score = 0
x_speed, y_speed = 7, -7
move_speed = 6
game_state = 'start'
count = 0

ball = Actor('ball', (300, 300))
coin = [Actor('coin', (150, 150)), Actor('coin', (300, 150))]
panel = Actor('panel', (225, 500))


def draw():
    global game_state
    if game_state == 'start':
        screen.fill('gold')
        screen.draw.text('Bounce Ball', (136, 260), fontsize=50)
        screen.draw.text('Press SPACE to start!', (132, 310),
                         fontsize=30)
        if keyboard.space:
            game_state = 'play'
    elif game_state == 'play':
        screen.fill('gold')
        screen.draw.text('score: ' + str(score), (10, 10),
                         fontsize=30)
        panel.draw()
        ball.draw()
        for i in range(len(coin)):
            coin[i].draw()
    else:
        screen.fill('gold')
        panel.draw()
        ball.draw()
        for i in range(len(coin)):
            coin[i].draw()
        screen.draw.text('Game Over', (136, 260),
                         color='red', fontsize=50)
        screen.draw.text('Your Score: ' + str(score),
                         (140, 310), fontsize=40)


def update():
    global game_state, score, x_speed, y_speed, count
    if game_state == 'play':
        ball.x += x_speed
        ball.y += y_speed

        if ball.x < 25 or ball.x > WIDTH - 25:
            x_speed = - x_speed
            ball.x += x_speed
        if ball.y < 25:
            y_speed = - y_speed
            ball.y += y_speed
        elif ball.y > HEIGHT - 30:
            game_state = 'game over'

        if keyboard.a:
            panel.x -= move_speed
        elif keyboard.d:
            panel.x += move_speed
        elif keyboard.w:
            panel.y -= move_speed
        elif keyboard.s:
            panel.y += move_speed

        if count == 0:
            if panel.colliderect(ball):
                y_speed = - y_speed
                sounds.bounce.play()
                count = 1
        else:
            count += 1
            if count > 60:
                count = 0

        for i in range(len(coin)):
            if coin[i].collidepoint(ball.pos):
                score += 1
                sounds.coin.play()
                coin[i].x = random.randint(30, WIDTH - 30)
                coin[i].y = random.randint(30, HEIGHT / 2)


pgzrun.go()

import pgzrun
import random

WIDTH = 450
HEIGHT = 650
game_state = 'start'
y_speed = 11
score = 0
count_list = [0, 0, 0]
combo = 0
level = 0
music_list = ['bg_music1', 'bg_music2', 'bg_music3']
level_color = ['lightgreen', 'lightsalmon', 'lightblue']

block = [Actor('blue_block1'), Actor('orange_block1'),
         Actor('red_block1')]
block_bottom = [Actor('blue_block2'), Actor('orange_block2'),
                Actor('red_block2')]
block_height = block[0].height
animate_image = ['blue_block2', 'orange_block2', 'red_block2',
                 'blue_block3', 'orange_block3', 'red_block3']

for i in range(3):
    block[i].x = 75 + 150 * i
    block[i].y = -150 * i
    block_bottom[i].x = 75 + 150 * i
    block_bottom[i].y = HEIGHT - 100


def draw():
    global game_state, score, level
    if game_state == 'start':
        screen.fill('gold')
        screen.draw.text('Music Block', (120, 260), fontsize=50)
        screen.draw.text('Press SPACE to start!',
                         (120, 300), fontsize=30)
        if keyboard.space:
            game_state = 'level update'
    elif game_state == 'level update':
        level += 1
        if level <= 3:
            music.play(music_list[level - 1])
            score = 0
            game_state = 'play'
        else:
            game_state = 'game over'
    elif game_state == 'play':
        screen.fill(level_color[level - 1])
        for i in range(3):
            screen.draw.filled_rect(
                Rect((73 + 150 * i, 0, 4, HEIGHT)), (150, 150, 150))
            block[i].draw()
            block_bottom[i].draw()
        screen.draw.text('score: ' + str(score), (10, 10), fontsize=40)
        if combo >= 3:
            screen.draw.text('Combo: ' + str(combo),
                             (120, 300), fontsize=60)
    else:
        screen.fill('gold')
        screen.draw.text('You Win!', (125, 270), fontsize=70)
        music.stop()


def update():
    global game_state, y_speed, score, count_list, combo
    if game_state == 'play':
        for i in range(3):
            block[i].y += y_speed

            if block[i].colliderect(block_bottom[i]):
                key = 6
                if keyboard.a:
                    key = 0
                elif keyboard.s:
                    key = 1
                elif keyboard.d:
                    key = 2
                if key == i:
                    score += 10
                    block[i].y = random.randint(-500, -50)
                    block_bottom[i].image = animate_image[i + 3]
                    count_list[i] = 1
                    combo += 1

            if count_list[i] > 0:
                count_list[i] += 1
                if count_list[i] > 10:
                    count_list[i] = 0
                    block_bottom[i].image = animate_image[i]

            if block[i].y > HEIGHT + block_height / 2:
                block[i].y = random.randint(-500, -50)
                score += combo * 2
                combo = 0

            if y_speed < 24:
                y_speed = 8 + level * 4 + score // 800

            if score >= 3000:
                game_state = 'level update'


pgzrun.go()

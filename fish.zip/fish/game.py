from arcade import *
from PIL import Image
import random
# Untill you do not use arcade 2.0.9 it will be TypeError.
SCREEN_WIDTH = 900
SCREEN_HIEGHT = 600
SCREEN_TITLE = "大鱼吃小鱼"
MOVEMENT_SPEED = 4
LEFT = 0
RIGHT = 1


class Player(Sprite):
    def __init__(self, image):
        super().__init__(image)
        self.center_x = SCREEN_WIDTH // 2
        self.center_y = SCREEN_HIEGHT // 2
        self.append_texture(load_texture(
            "resource/player.png", mirrored=True, scale=1))
        self.size = 2

    def update(self):
        super().update()
        if self.left < 0:
            self.left = 0
        elif self.right > SCREEN_WIDTH:
            self.right = SCREEN_WIDTH

        if self.top > SCREEN_HIEGHT:
            self.top = SCREEN_HIEGHT
        elif self.bottom < 0:
            self.bottom = 0

    def evolution(self, score):
        if score >= 1000:
            self.size = 10
            self.scale = 2
        elif score >= 500:
            self.size = 8
            self.scale = 1.5
        elif score >= 300:
            self.size = 6
            self.scale = 1.3
        elif score >= 200:
            self.size = 4
            self.scale = 1.2


class Enemy(Sprite):
    def __init__(self, image):
        super().__init__(image)
        face = random.choice(["left", "right"])
        speed = random.choice([1, 2, 3, 4, 5])
        if face == "left":
            self.center_x = SCREEN_WIDTH + 60
            self.change_x = -speed
        elif face == "right":
            self.center_x = -60
            self.append_texture(load_texture(image, mirrored=True, scale=1))
            self.set_texture(RIGHT)
            self.change_x = speed
        self.center_y = random.randint(0, SCREEN_HIEGHT)


class Status(Sprite):
    def __init__(self, image):
        super().__init__(image)
        self.center_x = SCREEN_WIDTH//2
        self.center_y = SCREEN_HIEGHT//2


class MyGame(Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        self.setup()

    def setup(self):
        Image.open("resource/sea.png").resize((SCREEN_WIDTH,
                                               SCREEN_HIEGHT)).save("resource/new_sea.png")
        self.background = Sprite("resource/new_sea.png")
        self.background.center_x = SCREEN_WIDTH // 2
        self.background.center_y = SCREEN_HIEGHT // 2
        self.player_sprite = Player("resource/player.png")
        self.player_sprite_list = SpriteList()
        self.player_sprite_list.append(self.player_sprite)
        self.fishes = {"resource/黄鱼.png": (1,10), "resource/绿鱼.png": (3,20),
                       "resource/红鱼.png": (5,30), "resource/紫鱼.png": (7,50), "resource/蓝鱼.png": (9,100)}
        self.enemy_sprite_list = SpriteList()
        self.total_time = 0
        self.last_time = 0
        self.create_num = 1
        self.score = 0
        self.game_over_status = False
        self.game_over = Status("resource/game_over.png")
        self.game_pause_status = False
        self.game_pause = Status("resource/game_pause.png")
        self.eat_sound = load_sound("resource/eat_sound.wav")
        self.game_over_sound = load_sound("resource/game_over_sound.wav")

    def on_draw(self):
        start_render()
        self.background.draw()
        self.player_sprite_list.draw()
        self.enemy_sprite_list.draw()
        draw_text(f"score:{self.score}", 0, SCREEN_HIEGHT-20,
                  color.WHEAT, font_name=("simhei", "PingFang"), font_size=20)
        if self.game_over_status :
            self.game_over.draw()
            if int(self.total_time) % 2 == 0:
                draw_text(f"请按下 TAB 重新开始游戏", 300, 100,
                        color.WHEAT, font_name=("simhei", "PingFang"), font_size=20)
                
        if self.game_pause_status:
            self.game_pause.draw()

    def on_update(self, delta_time):
        self.total_time += delta_time
        if self.game_over_status or self.game_pause_status:
            return
        self.total_time += delta_time
        if int(self.total_time) != int(self.last_time) and int(self.total_time) % 300 == 0:
            self.create_num += 1
        if int(self.total_time) != int(self.last_time) and int(self.total_time) % 1 == 0:
            self.create_enemy()
            self.last_time = self.total_time
        self.player_sprite_list.update()
        self.enemy_sprite_list.update()
        for enemy in self.enemy_sprite_list:
            if enemy.center_x < -60 or enemy.center_x > SCREEN_WIDTH + 60:
                enemy.kill()
        hit_list = check_for_collision_with_list(
            self.player_sprite, self.enemy_sprite_list)
        if hit_list:
            for hit in hit_list:
                if self.player_sprite.size > hit.size:
                    play_sound(self.eat_sound)
                    hit.kill()
                    self.score += hit.score
                else:
                    self.player_sprite.kill()
                    self.game_over_status = True
                    play_sound(self.game_over_sound)
        self.player_sprite.evolution(self.score)

    def on_key_press(self, symbol, modifiers):
        if symbol == key.UP:
            self.player_sprite.change_y = MOVEMENT_SPEED
        elif symbol == key.DOWN:
            self.player_sprite.change_y = -MOVEMENT_SPEED
        elif symbol == key.LEFT:
            self.player_sprite.change_x = -MOVEMENT_SPEED
            self.player_sprite.set_texture(LEFT)
        elif symbol == key.RIGHT:
            self.player_sprite.change_x = MOVEMENT_SPEED
            self.player_sprite.set_texture(RIGHT)
        elif symbol == key.RETURN:
            image = get_image(0, 0, SCREEN_WIDTH, SCREEN_HIEGHT)
            image.save("screenshot.png")
        elif symbol == key.ESCAPE:
            self.game_pause_status = not self.game_pause_status
        elif symbol == key.TAB:
            if self.game_over_status:
                self.setup()

    def on_key_release(self, symbol, modifiers):
        if symbol == key.UP or symbol == key.DOWN:
            self.player_sprite.change_y = 0
        elif symbol == key.LEFT or symbol == key.RIGHT:
            self.player_sprite.change_x = 0

    def create_enemy(self):
        for i in range(self.create_num):
            fish = random.choices(list(self.fishes.keys()),[0.5,0.1,0.06,0.04,0.3])[0]
            enemy_sprite = Enemy(fish)
            enemy_sprite.size = self.fishes[fish][0]
            enemy_sprite.score = self.fishes[fish][1]
            self.enemy_sprite_list.append(enemy_sprite)


if __name__ == '__main__':
    game = MyGame(SCREEN_WIDTH, SCREEN_HIEGHT, SCREEN_TITLE)
    run()
